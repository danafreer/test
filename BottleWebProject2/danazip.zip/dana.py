# test
from bottle import route, template

@route('/dana')
def hellodana():
    return "Hello Dana xxx!"